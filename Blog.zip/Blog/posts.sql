-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.2
-- Generation Time: Jun 05, 2020 at 06:09 AM
-- Server version: 5.7.30-33-log
-- PHP Version: 7.3.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trandoin_trando`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) NOT NULL,
  `datetime` varchar(50) NOT NULL,
  `title` varchar(300) NOT NULL,
  `category` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `post` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `datetime`, `title`, `category`, `author`, `image`, `post`) VALUES
(21, 'May-27-2020  09: 57: 37', ' Why Digital Marketing is So Engaging? ', 'Web Development Services', 'Dhanwantpal Singh', '8.png', '								Hey Guys! As you are asking about Digital Marketing, So I will explain it in the very sophisticated way. I will give you a choice to call it Digital Marketing, Internet Marketing, Modern Marketing or Online Marketing whatever you want to call it, because it is done all by digital platform. \r\n\r\nDigital Marketing? Any type of Activity which helps an organization to sell its services or products on digital channels. Digital Marketing is very effective way of selling products or services at this time and is also going on increasing in different forms. Traditional way of marketing is very costly and not so worthy as digital marketing. \r\n\r\nBecause, Approximately 57% or 4.43 billion people of world are active users of internet who are using internet in different ways. 1.8 billion of world population uses YouTube monthly for their entertainment, 2.45 billion of world population uses Facebook and 26.9 million uses Instagram for connecting with their relatives and friend and 92.71% People of world population uses Google as A search Engine. And there are many more social media platform which includes LinkedIn, Snap chat, Tiktok, Whatsapp, pintrest etc. \r\n\r\nSo when we think about digital marketing we also think about such platforms. These platforms are very helpful in promoting any service or product and generate lead. And after getting lead an organization can convert this lead into Your product/service buyer though different channel of digital marketing (eg. Drip-marketing).\r\n\r\n Types of Digital Marketing: For accomplishing our Marketing Goals there are many Digital Marketing channels:\r\n1 ) Social Media Marketing (SMM)\r\n 2) Search Engine Marketing (SEM) \r\n3) Search Engine Optimization (SEO) \r\n4) Content Marketing(CM) \r\n5) Email Marketing or Drip Marketing \r\n6) Pay-Per-Click Advertising (PPC) \r\n7) Affiliate Marketing 8) Influencer Marketing\r\n 9) Viral Marketing \r\n10) Mobile Phone Advertising\r\n\r\n Selection of Marketing: Now when we are going to perform digital marketing steps for an organization then the selection of the platform depends on the types of people to whom we want to target for effective Results. \r\n\r\nFor Example: Letâ€™s assume you are going to start a Social Media Marketing campaign, Then first You need to know that who are your customers? If your product is for businesses then, your customers will be of Business to Business (B2B) category then LinkedIn is the most suitable platform for your campaign and if your product is for individuals then customers will be informal people and these will lie under Business to Customer (B2C) category thus for this purpose Facebook, Instagram, YouTube and Snap chat are most suitable platforms where you can target to your customers														');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
