<?php 

header("refresh:5;url = Blog.php?page=1");
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Domain-BloG</title>
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-167474688-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-167474688-2');
</script>

</head>
<style>
/* Center the loader */
*, ::before, ::after {
    box-sizing: border-box;
    font-family: sans-serif;
    margin: 0;
  }
  #loader{
      top: 50%;
      left: 50%;
      transform: translate(-50%,50%);
  }
  .loader {
    position: relative;
    display: block;
    height: 50vh; width: 100%;
    min-height: 250px;
    float: left;
    z-index: 100;
    border: 2px solid #fff;
    overflow: hidden;
  }
  
  @media screen and (min-width: 425px) {
    .loader { width: 50%; }
  }
  @media screen and (min-width: 768px) {
    .loader { width: 33.33%; }
  }
  @media screen and (min-width: 1440px) {
    .loader { width: 25%; }
  }
  /* loader-43 */

    .loader-43 .loader-holder {
      position: absolute;
      top: 50%; left: 50%;
      transform: translate(-50%, -50%) scale(1, 1) translateZ(0);
      width: 250px; height: 250px;
      border: 3px solid rgb(240,240,241);
      border-radius: 50%;
      overflow: hidden;
    }
    .loader-43 .loader-holder::before {
      position: absolute;
      content: "";
      display: block;
      bottom: 0; left: 50%;
      transform: translate(-50%, 104%);
      width: 370px; height: 250px;
      border-radius: 50%;
      background-color: #0067f4;
      animation: moveBefore43 5s forwards linear;
      z-index: 1;
    }
      .loader-43 .loader-container {
        position: absolute;
        top: 50%; left: 50%;
        transform: translate(-50%, -50%) scale(1, 1) translateZ(0);
        width: 250px; height: 250px;
        border-radius: 50%;
        border-top: 5px solid rgb(240,240,241);
        overflow: hidden;
        animation: spin43 2s infinite linear;
        z-index: 2;
      }
  
      .loader-43 p {
        position: absolute;
        top: 50%; left: 50%;
        font-size: 35px;
        font-weight: 900;
        color: #ef4361;
        z-index: 2;
        transform: translate(-50%, -50%);
        -webkit-text-stroke-width: 1px;
        -webkit-text-stroke-color: rgb(240,240,241);
      }
  @keyframes moveBefore43 {
    0%   { transform: translate(-50%, 104%); }
    80%  { transform: translate(-50%, 50%); }
    100% { transform: translate(-50%, 0%); }
  }
  @keyframes spin43 {
    0%   { transform: translate(-50%, -50%) scale(1, 1) translateZ(0) rotate(0deg); }
    100% { transform: translate(-50%, -50%) scale(1, 1) translateZ(0) rotate(360deg)}
  }
  
  /* Add animation to "page content" */
  .animate-bottom {
    position: relative;
    -webkit-animation-name: animatebottom;
    -webkit-animation-duration: 1s;
    animation-name: animatebottom;
    animation-duration: 1s
  }
  
  @-webkit-keyframes animatebottom {
    from { bottom:-100px; opacity:0 } 
    to { bottom:0px; opacity:1 }
  }
  
  @keyframes animatebottom { 
    from{ bottom:-100px; opacity:0 } 
    to{ bottom:0; opacity:1 }
  }
  
  #myDiv {
    display: none;
    text-align: center;
  }
  </style>
<body  onload="myFunction()" style="margin:0;">
    <div id="loader" class=" loader loader-43">
                <div class='loader-holder'>
                  <div class="loader-container"></div>
                </div>
                <p class='loader-title'>Domain</p>
              </div>

<script>
    
    var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 5000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>
</body>
</html>