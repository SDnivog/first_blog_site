<?php 
$Hostname = "http://localhost/Trando/Job%20Portal/Blog";
$DSN ='mysql:host = localhost; dbname=job_portal';  #NOT ADD any Space between dbname & '=' sign
$ConnectingDB = new PDO($DSN,'root','');

 ?>